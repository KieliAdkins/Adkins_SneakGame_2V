﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shot : MonoBehaviour
{
    // Declaring our variables
    public float moveSpeed;
    private Transform tf;

    // Use this for initialization
    void Start()
    { 
        // Acquiring component for movement
        tf = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        // Changing the position of the Game Object
        tf.position = tf.position + (GetComponent<Transform>().up * moveSpeed);

        // Destroy the bullet after 2 seconds
        Destroy(gameObject, 2.0f);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Destroy(collision.gameObject);
        Destroy(gameObject);
    }
}
