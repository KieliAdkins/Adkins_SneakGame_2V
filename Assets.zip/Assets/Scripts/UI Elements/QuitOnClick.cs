﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitOnClick : MonoBehaviour {

    // Declaring quit function
    public void Quit()
    {
        // Quitting the application
        Application.Quit(); 
    }
}
