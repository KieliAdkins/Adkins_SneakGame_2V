﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    // Declaring variables
    public float cutoff; // if our health is below this, we will stop and heal
    public float restingHealRate; // in hp/framedraw  

    public float health;
    private Transform tf;
    public GameObject target;
    public float speed;
    private float maxHealth = 100;
    private bool enemyIdle = true;
    private bool enemyHealth = false;

    // Setting enemy AI hearing components
    public CircleCollider2D hearing;
    public float hearingRadius = 0f;

    private void Start()
    {
        // Acquiring component for movement
        tf = GetComponent<Transform>();

        // Setting the distance the enemy can hear
        hearing.radius = hearingRadius; 
    }
    public void DoIdle()
    {
        // Do Nothing
    }

    public void DoSeek()
    {
        ////If sound level is detectable
        ////if (GameManager.instance.soundLevel > 0)
        ////{
        ////    Vector3 vectorToTarget = target.transform.position - tf.position;
        ////    tf.position += vectorToTarget.normalized * speed;
        ////}

        ////Else
        ////else
        ////{
        ////    Calling rest function
        ////    DoRest();
        ////}
    }

    public void DoRest()
    {
        // Increase our health
        health += restingHealRate;

        // But never go over our max health
        health = Mathf.Min(health, maxHealth);
    }

    void Update()
    {
        if (enemyIdle == true)
        {
            // Do Action
            DoIdle();
            // Check for transitions
            //if (Vector3.Distance(transform.position, tf.position) < aiSenseRadius)
            //{
            //    enemyIdle = false;
            //}
        }

        else if (enemyIdle == false)
        {
            // Do Action
            DoSeek();
            // Check for transitions
            //if (Vector3.Distance(transform.position, tf.position) > aiSenseRadius)
            //{
            //    enemyIdle = true;
            //}
            if (health < cutoff)
            {
                enemyHealth = true;
            }
        }

        else if (enemyHealth == true)
        {
            // Do Action
            DoRest();
            // Check for transitions
            if (health > cutoff)
            {
                enemyHealth = false;
            }
        }

    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        NoiseMaker other = collision.GetComponent<NoiseMaker>(); 
        if (other == null)
        {
            Debug.Log("Null");
        }

        else if (collision == other.volume)
        {
            Debug.Log("Heard");

            TankMovement();
        }
    }

    private void TankMovement()
    {
        float step = speed * Time.deltaTime;
        tf.position = Vector3.MoveTowards(transform.position, target.transform.position, step)
;    }
}
