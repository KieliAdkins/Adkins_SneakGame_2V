﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    // Declaring variables
    public float moveSpeed;
    public float turnSpeed;
    private Transform tf; 

    // Setting the Noise Level
    public float volume;

    public GameObject tankShot;
    public Transform tankSpawn;
    internal Quaternion rotation;

    public Transform bulletPrefab;

    // Use this for initialization
    void Start () {
        // Acquiring component for movement
        tf = GetComponent<Transform>();
    }
	
	// Update is called once per frame
	void Update () {
        // if statement for up key controlled movement
        if (Input.GetKey(KeyCode.UpArrow))
        {
            tf.position = tf.position + (GetComponent<Transform>().up * moveSpeed * Time.deltaTime);
        }

        // if statement for right key controlled movement
        if (Input.GetKey(KeyCode.RightArrow))
        {
            tf.Rotate(0, 0, -turnSpeed);
        }

        // if statement for left key controlled movement
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            tf.Rotate(0, 0, turnSpeed);

        }

        // if statement for down key controlled movement
        if (Input.GetKey(KeyCode.DownArrow))
        {
            tf.position = tf.position + (-GetComponent<Transform>().up * moveSpeed * Time.deltaTime);
        }

        // if statement for shooting 
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Instantiate(tankShot, tankSpawn.position, tankSpawn.rotation);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (gameObject.tag != "Sandbags")
        {
            NoiseMaker other = collision.GetComponent<NoiseMaker>();
            if (other == null)
            {
                Debug.Log("Null");
            }

            else if (collision == other.volume)
            {
                Debug.Log("Heard");
            }
        }
    }

    private void OnDestroy()
    {
        // Subtracting a life
        GameManager.instance.playerLives -= 1;

        // Setting player back to beginning position 
        tf.position = new Vector3(7, -2, 0);
    }
}
